
public class TotalNilai {
    public static void main(String[] args) {
        System.out.println("Nama: Aljer Kamilo");
        System.out.println("NIM: 1202220370");
        float NilaiTubes= ((30 * 80)/100);
        float NilaiQuiz= ((10 * 95)/100);
        float NilaiTugas= ((10 * 85)/100 );
        float NilaiUTS= ((25 * 80)/100);
        float NilaiUAS= ((25 *75)/100);
        float NilaiTotal= (NilaiTubes + NilaiQuiz + NilaiTugas + NilaiUTS + NilaiUAS); 
        System.out.println("Nilai Matakuliah Pemograman Berorientasi Objek : "+NilaiTotal );
    }
}